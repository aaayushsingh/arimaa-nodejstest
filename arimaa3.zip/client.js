var app = require("express");
var http = require("http").Server(app);

//connect to the server at localhost:5050
var socket = require("socket.io-client")(`http://localhost:5050`);

//read commands from cli
var readcommand = require("readcommand");

//start server at the given address and port.
// format node client 127.0.0.1 3000 -- will start client at port 3000
http.listen(process.argv[3], process.argv[2], function() {
  console.log(`connected to ${process.argv[2]} : ${process.argv[3]}`);
});

socket.on("event", function(data) {
  console.log(data);
});

// terminate program on socket disconnection
socket.on("disconnect", function(data) {
  process.exit(0);
});

// display msg event to console
socket.on("msg", function(data) {
  console.log(data);
});

readcommand.loop(function(err, args, str, next) {
  // exit client if input is 'r'
  if (args[0] == "r") {
    process.exit(0);
  }

  // else check validity of inputs
  if (args[0] <= 9 && args[0] >= 1) {
    //console.log("Received args: %s", JSON.stringify(args));
    socket.emit("move", args[0]);
  } else {
    console.log("invalid move, select a number between 1-9");
  }
  return next();
});
